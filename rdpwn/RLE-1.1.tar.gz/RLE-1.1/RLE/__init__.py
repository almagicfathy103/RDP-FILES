#! usr/bin/env python
from RLE import Compressor
